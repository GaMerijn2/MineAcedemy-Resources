<p align="center">
  <small><i>Learn Java, code Minecraft plugins and launch a unique network from the ground up in 20 days (without experience):</i></small>
  <a href="https://mineacademy.org/project-orion?st=github&sc=plugintemplate&utm_source=github&utm_medium=overview&utm_campaign=plugintemplate">
    <img src="https://i.imgur.com/SVHA9Kf.png" />
  </a>
</p>

# PluginTemplate
A bootstrap plugin to use when creating high-performance plugins with Foundation.
